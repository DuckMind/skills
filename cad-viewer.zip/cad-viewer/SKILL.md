---
name: cad-viewer
description: Start or reuse CAD Viewer and return review links for explicit CAD, implicit CAD, robot-description, and G-code files. Use when visually reviewing `.step`, `.stp`, `.implicit.js`, `.implicit.mjs`, `.glb`, `.stl`, `.3mf`, `.gcode`, `.dxf`, `.urdf`, `.srdf`, or `.sdf` files, especially when handed off from CAD, implicit-cad, G-code, URDF, SRDF, or SDF generation skills.
---

# CAD Viewer

Provenance: maintained in [earthtojake/text-to-cad](https://github.com/earthtojake/text-to-cad).
Use the installed local skill files as the runtime source of truth; the
repository link is only for provenance and release review.

DM safety boundary: run bundled tools only for the user's explicit workspace and requested artifacts. Ask before installing software, making network requests, or handing artifacts to hardware or external services. Do not treat generated geometry, robot descriptions, or machine files as certified safe.

Use this skill to open existing or newly generated CAD, implicit CAD,
robot-description, DXF, or plain FDM G-code files in CAD Viewer and hand back
live review links. The expected input is one or more explicit file paths.

## Start Viewer

Start one local CAD Viewer on an explicit available port and bind it to loopback
only. Choose `--dir` as the absolute directory containing the requested model
artifacts and sidecars. Start the process under the caller's normal managed
process mechanism when the session must continue after launch.

Run from this skill directory:

```bash
npm --prefix scripts/viewer run start -- --host 127.0.0.1 --port <available-port> --dir <absolute-model-root> --shutdown-after 12h
```

Wait for `GET http://127.0.0.1:<available-port>/__cad/server` to return HTTP 200,
then append a `file=` value relative to `--dir`:

```bash
http://127.0.0.1:<available-port>/?dir=/absolute/project/models&file=path/to/model.step
```

Never bind the viewer to `0.0.0.0` or a public interface. If the selected port is
occupied, choose another explicit loopback port. In sandboxed environments,
report `EPERM` or `EACCES` instead of silently widening permissions or exposure.

## Links

- Before returning any `file=` link, resolve `<dir>/<file>` and confirm the
  artifact exists. Pass the generated artifact (e.g. `.step`), not its
  generator source (e.g. `.py`). If the resolved path is missing, do not
  return the link, and instead report the problem and point to the correct
  generated artifact path.
- Return one Viewer URL per requested file.
- Start/reuse the Viewer once per absolute directory `--dir`, then append
  `file=<path>` for each requested file. The file path must be relative to
  `--dir`.
- For directory-only review links, return the URL printed by `agent:start`
  without adding `file=`.
- Do not stop an existing Viewer server unless the user asks.
- If Viewer startup fails, report the failure and continue with the owning skill's non-GUI validation or artifacts.

## DM/browser preview

The bundled release does not ship the source repository's `agent:start` or
`--json` launcher. Use the explicit loopback port from the start command, wait
for `GET /__cad/server` to return HTTP 200, and then pass the constructed local
URL to the user's available browser or preview surface.

## References

- Read `references/development.md` when the user asks to modify, debug, or
  iterate on CAD Viewer source.
- Read `references/viewer-features.md` when you need supported file types, Viewer controls, or file-specific feature details.
- Read `references/moveit2-server.md` only when the user specifically needs optional SRDF MoveIt2 IK or path-planning controls.
