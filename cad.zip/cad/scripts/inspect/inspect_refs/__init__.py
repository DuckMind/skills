"""Selector reference inspection helpers."""
