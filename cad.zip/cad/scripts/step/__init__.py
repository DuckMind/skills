"""Unified STEP generation CLI."""
