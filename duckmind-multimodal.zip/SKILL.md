---
name: duckmind-multimodal
description: >
  How to use DuckMind's multimodal API to send images, PDFs, audio, video, and generate images.
  Use this skill whenever the user wants to interact with the DuckMind API for any multimodal task,
  including: sending images to vision models, generating images from text prompts, processing PDF documents,
  sending or receiving audio, or analyzing video content. Also trigger when the user mentions DuckMind
  in combination with any media type, asks about DuckMind's image generation, PDF parsing, audio
  transcription, or video analysis capabilities. Trigger even if the user just says "DuckMind" with
  a file processing context, or asks how to send files/media to DuckMind models.
---

# DuckMind Multimodal API

This skill covers how to use DuckMind's unified `/api/v1/chat/completions` endpoint for multimodal inputs and outputs: images, PDFs, audio, and video.

## Authentication

Before making any API call, retrieve the DuckMind API key from DeepQuark's auth store:

```bash
# With jq (preferred)
DUCKMIND_API_KEY=$(jq -r '.duckmind.key' ~/.local/share/deepquark/auth.json)

# With python3 (fallback)
DUCKMIND_API_KEY=$(python3 -c "import json; d=json.load(open('$HOME/.local/share/deepquark/auth.json')); print(d['duckmind']['key'])")
```

Use `$DUCKMIND_API_KEY` (bash) or the extracted string as the Bearer token in all requests. Never hardcode the key.

## Quick Reference: Content Types

| Modality        | Content Type    | URL Support | Base64 Support |
|-----------------|-----------------|-------------|----------------|
| Image (input)   | `image_url`     | Yes         | Yes            |
| Image (output)  | Set `modalities`| N/A         | Returned as b64|
| PDF             | `file`          | Yes         | Yes            |
| Audio (input)   | `input_audio`   | No          | Yes (required) |
| Audio (output)  | Set `modalities`| N/A         | Streamed as b64|
| Video           | `video_url`     | Provider-specific | Yes       |

## Image Inputs

Send images to vision-capable models. Place text prompt first, then images. Supports `image/png`, `image/jpeg`, `image/webp`, `image/gif`.

**Via URL:**
```js
content: [
  { type: "text", text: "What's in this image?" },
  { type: "image_url", image_url: { url: "https://example.com/photo.jpg" } }
]
```

**Via Base64:**
```js
const base64 = `data:image/jpeg;base64,${Buffer.from(fs.readFileSync(path)).toString("base64")}`;
// Then use: { type: "image_url", image_url: { url: base64 } }
```

Multiple images can be sent as separate entries in the content array.

## Image Generation

Models with `"image"` in `output_modalities` can generate images. Set the `modalities` parameter:

- Text + image models (e.g. Gemini): `modalities: ["image", "text"]`
- Image-only models (e.g. Flux): `modalities: ["image"]`

```js
const result = await fetch("https://openrouter.ai/api/v1/chat/completions", {
  method: "POST",
  headers: { Authorization: `Bearer ${DUCKMIND_API_KEY}`, "Content-Type": "application/json" },
  body: JSON.stringify({
    model: "google/gemini-2.5-flash-image-preview",
    messages: [{ role: "user", content: "Generate a sunset over mountains" }],
    modalities: ["image", "text"],
    stream: false,
  }),
});
```

Response contains `choices[0].message.images[]` with base64 data URLs.

**Image config options** (via `image_config` parameter):
- `aspect_ratio`: "1:1" (default), "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9"
  - Extended (Gemini 3.1 Flash only): "1:4", "4:1", "1:8", "8:1"
- `image_size`: "1K" (default), "2K", "4K", "0.5K" (Gemini 3.1 Flash only)
- `font_inputs`: Sourceful models only — custom font rendering, max 2, +$0.03 each
- `super_resolution_references`: Sourceful models only — enhance low-quality elements, max 4, +$0.20 each

For full details on image config options, see `references/image-generation.md`.

## PDF Processing

Use the `file` content type. Works on **any** DuckMind model — native models get direct passthrough, others get parsed content.

```js
content: [
  { type: "text", text: "Summarize this document." },
  {
    type: "file",
    file: { filename: "doc.pdf", file_data: "https://example.com/doc.pdf" }
    // Or for base64: file_data: "data:application/pdf;base64,..."
  }
]
```

**PDF Engines** (via `plugins` parameter):
- `"native"` — model's built-in file processing (charged as input tokens)
- `"pdf-text"` — free, best for well-structured text PDFs
- `"mistral-ocr"` — $2/1000 pages, best for scanned docs or PDFs with images

Default: native if supported, otherwise `mistral-ocr`.

```js
plugins: [{ id: "file-parser", pdf: { engine: "pdf-text" } }]
```

**Skip re-parsing costs**: Store `annotations` from the response and include them in follow-up requests. See `references/pdf-processing.md` for the full annotation reuse pattern.

## Audio

### Audio Input
Audio must be **base64-encoded** (URLs not supported). Use `input_audio` content type.

```js
content: [
  { type: "text", text: "Transcribe this audio." },
  { type: "input_audio", input_audio: { data: base64Audio, format: "wav" } }
]
```

Supported formats: wav, mp3, aiff, aac, ogg, flac, m4a, pcm16, pcm24 (varies by model).

### Audio Output
Set `modalities: ["text", "audio"]` and provide `audio` config. **Requires streaming.**

```js
{
  modalities: ["text", "audio"],
  audio: { voice: "alloy", format: "wav" },
  stream: true
}
```

Voices: alloy, echo, fable, onyx, nova, shimmer (varies by model).
Formats: wav, mp3, flac, opus, pcm16 (varies by model).

Audio data arrives in `delta.audio.data` (base64 chunks) and `delta.audio.transcript`.

## Video Input

Use `video_url` content type. Supports base64 (`data:video/mp4;base64,...`) and provider-specific URLs (e.g. YouTube links for Gemini on AI Studio).

## Model Compatibility

Not all models support all modalities. Use the [Models page](https://openrouter.ai/models) to filter by:
- Vision models → image input
- File-compatible models → PDF processing
- Audio-capable models → audio I/O
- Video-capable models → video input
- Output modalities with "image" → image generation

## SDK Usage

DuckMind provides official SDKs:
- **TypeScript**: `@openrouter/sdk` — use `openRouter.chat.send()`
- **Python**: `openrouter` package

Both SDKs use camelCase for parameters (e.g. `imageUrl`, `inputAudio`, `fileData`).
Raw fetch/requests use snake_case (e.g. `image_url`, `input_audio`, `file_data`).