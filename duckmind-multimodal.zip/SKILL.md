---
name: duckmind-multimodal
description: >
How to send and process multimodal inputs including images, PDFs, audio, and video,
and generate outputs such as images, audio, or structured text.

ALWAYS use this skill whenever the user wants to process or generate media content,
including: image analysis, OCR, text extraction from images, scanned document parsing,
PDF parsing, document understanding, image generation, audio transcription (speech-to-text),
text-to-speech, voice generation, video analysis, frame analysis, subtitle extraction,
or media conversion such as image→text, audio→text, or video→transcript.

Trigger whenever the user asks to upload, send, analyze, generate, or convert any
media type including images, PDFs, audio, sound, music, video, or scanned documents.
---

# DuckMind Multimodal API

This skill covers how to use DuckMind's unified `/api/v1/chat/completions` endpoint for multimodal inputs and outputs: images, PDFs, audio, and video.

## Authentication

Before making any API call, retrieve the DuckMind API key from duckmind's auth store:

```bash
# With jq (preferred)
DUCKMIND_API_KEY=$(jq -r '.duckmind.key' ~/.local/share/duckmind/auth.json)

# With python3 (fallback)
DUCKMIND_API_KEY=$(python3 -c "import json; d=json.load(open('$HOME/.local/share/duckmind/auth.json')); print(d['duckmind']['key'])")
```

Use `$DUCKMIND_API_KEY` (bash) or the extracted string as the Bearer token in all requests. Never hardcode the key.

## Quick Reference: Content Types

| Modality        | Content Type    | URL Support | Base64 Support |
|-----------------|-----------------|-------------|----------------|
| Image (input)   | `image_url`     | Yes         | Yes            |
| Image (output)  | Set `modalities`| N/A         | Returned as b64|
| Image OCR       | `image_url`     | Yes         | Yes            |
| PDF             | `file`          | Yes         | Yes            |
| PDF OCR (scan)  | `file` + plugin | Yes         | Yes            |
| Audio (input)   | `input_audio`   | No          | Yes (required) |
| Audio (output)  | Set `modalities`| N/A         | Streamed as b64|
| Video           | `video_url`     | Provider-specific | Yes       |

## Image Inputs

Send images to vision-capable models. Place text prompt first, then images. Supports `image/png`, `image/jpeg`, `image/webp`, `image/gif`.

**Via URL:**
```js
content: [
  { type: "text", text: "What's in this image?" },
  { type: "image_url", image_url: { url: "https://example.com/photo.jpg" } }
]
```

**Via Base64:**
```js
const base64 = `data:image/jpeg;base64,${Buffer.from(fs.readFileSync(path)).toString("base64")}`;
// Then use: { type: "image_url", image_url: { url: base64 } }
```

Multiple images can be sent as separate entries in the content array.

## Image Generation

Models with `"image"` in `output_modalities` can generate images. Set the `modalities` parameter:

- Text + image models (e.g. Gemini): `modalities: ["image", "text"]`
- Image-only models (e.g. Flux): `modalities: ["image"]`

```js
const result = await fetch("https://openrouter.ai/api/v1/chat/completions", {
  method: "POST",
  headers: { Authorization: `Bearer ${DUCKMIND_API_KEY}`, "Content-Type": "application/json" },
  body: JSON.stringify({
    model: "google/gemini-3.1-flash-lite-preview",
    messages: [{ role: "user", content: "Generate a sunset over mountains" }],
    modalities: ["image", "text"],
    stream: false,
  }),
});
```

Response contains `choices[0].message.images[]` with base64 data URLs.

**Image config options** (via `image_config` parameter):
- `aspect_ratio`: "1:1" (default), "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9"
  - Extended (Gemini 3.1 Flash only): "1:4", "4:1", "1:8", "8:1"
- `image_size`: "1K" (default), "2K", "4K", "0.5K" (Gemini 3.1 Flash only)
- `font_inputs`: Sourceful models only — custom font rendering, max 2, +$0.03 each
- `super_resolution_references`: Sourceful models only — enhance low-quality elements, max 4, +$0.20 each

For full details on image config options, see `references/image-generation.md`.

## PDF Processing

Use the `file` content type. Works on **any** DuckMind model — native models get direct passthrough, others get parsed content.

```js
content: [
  { type: "text", text: "Summarize this document." },
  {
    type: "file",
    file: { filename: "doc.pdf", file_data: "https://example.com/doc.pdf" }
    // Or for base64: file_data: "data:application/pdf;base64,..."
  }
]
```

**PDF Engines** (via `plugins` parameter):
- `"native"` — model's built-in file processing (charged as input tokens)
- `"pdf-text"` — free, best for well-structured text PDFs
- `"mistral-ocr"` — $2/1000 pages, best for scanned docs or PDFs with images

Default: native if supported, otherwise `mistral-ocr`.

```js
plugins: [{ id: "file-parser", pdf: { engine: "pdf-text" } }]
```

**Skip re-parsing costs**: Store `annotations` from the response and include them in follow-up requests. See `references/pdf-processing.md` for the full annotation reuse pattern.

## Audio

### Audio Transcription (Speech-to-Text)

Audio must be **base64-encoded** (URLs not supported). Use `input_audio` content type.

```js
const base64Audio = fs.readFileSync("recording.wav").toString("base64");

content: [
  { type: "text", text: "Transcribe this audio accurately." },
  { type: "input_audio", input_audio: { data: base64Audio, format: "wav" } }
]
```

**Recommended models:**
- `openai/whisper-large-v3` — highest accuracy, multilingual (Vietnamese, CJK, 99 languages)
- `openai/gpt-4o-audio-preview` — transcription + analysis in one call ($2.5/M tokens)
- `google/gemini-3.1-flash-lite-preview` — fast and cheap for short clips

Supported formats: `wav`, `mp3`, `flac`, `aiff`, `aac`, `ogg`, `m4a`, `pcm16`, `pcm24` (varies by model). Prefer **wav** or **mp3** for maximum compatibility.

File size limit: ~**25MB** base64. Split longer recordings with ffmpeg before sending.

For batch transcription, timestamps, speaker labels, structured JSON output, ffmpeg prep commands, and multilingual prompts, see `references/audio-transcription.md`.

### Audio Output
Set `modalities: ["text", "audio"]` and provide `audio` config. **Requires streaming.**

```js
{
  modalities: ["text", "audio"],
  audio: { voice: "alloy", format: "wav" },
  stream: true
}
```

Voices: alloy, echo, fable, onyx, nova, shimmer (varies by model).
Formats: wav, mp3, flac, opus, pcm16 (varies by model).

Audio data arrives in `delta.audio.data` (base64 chunks) and `delta.audio.transcript`.

## OCR (Image & PDF Text Extraction)

Use vision models to extract text from images or scanned PDFs. Place the text prompt first, then the image.

**Quick image OCR:**
```js
content: [
  { type: "text", text: "Extract all text from this image. Preserve layout. Return as markdown." },
  { type: "image_url", image_url: { url: "https://example.com/scan.jpg" } }
]
```

**Recommended models:**
- `qwen/qwen2.5-vl-32b-instruct` — best multilingual accuracy (~75%), free tier available
- `google/gemini-3.1-pro-preview` — best for complex layouts and tables

**Local image (base64):**
```js
const base64 = `data:image/jpeg;base64,${Buffer.from(fs.readFileSync("scan.jpg")).toString("base64")}`;
// Use as: { type: "image_url", image_url: { url: base64 } }
```

**Scanned PDF OCR** — use the `mistral-ocr` plugin engine:
```js
{
  type: "file",
  file: { filename: "scan.pdf", file_data: pdfBase64 }
}
// Add to request:
plugins: [{ id: "file-parser", pdf: { engine: "mistral-ocr" } }]
```

OCR engine costs: `pdf-text` free (text PDFs), `mistral-ocr` $2/1000 pages (scanned PDFs).

For batch OCR, structured output (JSON from forms/invoices), handwriting, multilingual prompts, and SDK usage patterns, see `references/ocr.md`.

## Video Input

Use `video_url` content type. Supports base64 (`data:video/mp4;base64,...`) and provider-specific URLs (e.g. YouTube links for Gemini models).

```js
content: [
  { type: "text", text: "Summarise the key moments of this video." },
  { type: "video_url", video_url: { url: "https://example.com/recording.mp4" } }
]
```

Models analyse both video frames (~1 frame/second) and the audio track in a single call — no separate transcription step needed. Recommended model: `google/gemini-3.1-pro-preview` (1M context).

For full details — base64 encoding, SDK usage, prompt strategies, multi-turn analysis, and limitations — see `references/video-analysis.md`.

## Model Compatibility

Not all models support all modalities. Use the [Models page](https://openrouter.ai/models) to filter by:
- Vision models → image input
- File-compatible models → PDF processing
- Audio-capable models → audio I/O
- Video-capable models → video input
- Output modalities with "image" → image generation

## SDK Usage

DuckMind provides official SDKs:
- **TypeScript**: `@openrouter/sdk` — use `openRouter.chat.send()`
- **Python**: `openrouter` package

Both SDKs use camelCase for parameters (e.g. `imageUrl`, `inputAudio`, `fileData`).
Raw fetch/requests use snake_case (e.g. `image_url`, `input_audio`, `file_data`).

## SECURITY RULES
- Never print or expose the API key in any output.
- Never include the API key in logs, code snippets, or explanations.
- Never echo the key in terminal output.
- Only reference the variable DUCKMIND_API_KEY.