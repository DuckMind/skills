# Audio Transcription — Detailed Reference

## How It Works

Audio transcription on DuckMind sends a base64-encoded audio file as `input_audio` in the message content. The model returns the transcript as plain text in `choices[0].message.content`.

**Important**: Audio input does **not** support URLs — base64 encoding is always required.

---

## Model Selection

| Model | Price | Formats | Best For |
|-------|-------|---------|----------|
| `openai/whisper-large-v3` | Low | wav, mp3 | Highest accuracy, multilingual (Vietnamese included) |
| `openai/gpt-4o-audio-preview` | $2.5/M tokens | wav, mp3, flac | Transcription + analysis/summarization in one call |
| `google/gemini-3.1-flash-lite-preview` | Low | mp3, wav | Fast, multimodal — transcribe + summarize |
| `google/gemini-3.1-pro-preview` | Higher | mp3, wav | Long audio, mixed language, complex analysis |

For **Vietnamese or multilingual audio**, `whisper-large-v3` is the most reliable choice.

For **transcription + follow-up analysis** (e.g. summarize a meeting), use `gpt-4o-audio-preview` or a Gemini model so both happen in a single call.

---

## Basic Transcription

### Encode and transcribe a local file

```js
import * as fs from "fs";
import * as path from "path";

function audioToBase64(filePath) {
  const buffer = fs.readFileSync(filePath);
  return buffer.toString("base64");
}

const base64Audio = audioToBase64("./recording.wav");

const result = await fetch("https://openrouter.ai/api/v1/chat/completions", {
  method: "POST",
  headers: {
    Authorization: `Bearer ${DUCKMIND_API_KEY}`,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    model: "openai/whisper-large-v3",
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: "Transcribe this audio accurately." },
          {
            type: "input_audio",
            input_audio: { data: base64Audio, format: "wav" },
          },
        ],
      },
    ],
  }),
});

const data = await result.json();
console.log(data.choices[0].message.content);
```

### Supported audio formats (varies by model)

`wav`, `mp3`, `flac`, `aiff`, `aac`, `ogg`, `m4a`, `pcm16`, `pcm24`

When in doubt, use **WAV or MP3** — they have the widest model support.

---

## SDK Usage (TypeScript)

```ts
import { OpenRouter } from "@openrouter/sdk";
import * as fs from "fs";

const client = new OpenRouter({ apiKey: process.env.DUCKMIND_API_KEY });

const base64Audio = fs.readFileSync("recording.mp3").toString("base64");

const response = await client.chat.send({
  model: "openai/whisper-large-v3",
  messages: [
    {
      role: "user",
      content: [
        { type: "text", text: "Transcribe this audio, support Vietnamese." },
        {
          type: "inputAudio",           // camelCase in SDK
          inputAudio: { data: base64Audio, format: "mp3" },
        },
      ],
    },
  ],
});

console.log(response.choices[0].message.content);
```

Note: the SDK uses **camelCase** (`inputAudio`). Raw fetch uses **snake_case** (`input_audio`).

---

## Transcription Prompts

Prompt quality matters. Use specific instructions:

| Goal | Prompt |
|------|--------|
| Plain transcript | `"Transcribe this audio accurately."` |
| With timestamps | `"Transcribe this audio. Include a timestamp (e.g. [00:12]) at the start of each sentence."` |
| Vietnamese | `"Chuyển âm thanh sang text chính xác. Ngôn ngữ: tiếng Việt."` |
| Multilingual | `"Transcribe this audio. Detect the language automatically. Do not translate."` |
| Speaker labels | `"Transcribe this audio. Label each speaker as Speaker 1, Speaker 2, etc."` |
| Transcribe + summarize | `"Transcribe this audio, then provide a concise summary of the key points."` |
| Meeting notes | `"Transcribe this meeting audio. Format output as: transcript, then action items."` |
| Noisy audio | `"Transcribe this audio. If a word is unclear, mark it as [inaudible]."` |

---

## Transcription + Analysis in One Call

Using `gpt-4o-audio-preview` or a Gemini model, you can transcribe and analyze in a single request:

```js
{
  model: "openai/gpt-4o-audio-preview",
  messages: [
    {
      role: "user",
      content: [
        {
          type: "text",
          text: `Transcribe this audio recording, then:
1. List action items mentioned
2. Summarize key decisions
3. Note any deadlines or dates mentioned`,
        },
        {
          type: "input_audio",
          input_audio: { data: base64Audio, format: "mp3" },
        },
      ],
    },
  ],
}
```

---

## Structured Output from Transcription

To get transcription results as structured JSON:

```js
{
  type: "text",
  text: `Transcribe this audio and return ONLY valid JSON:
{
  "transcript": "full text here",
  "language": "detected language",
  "duration_estimate": "approximate duration",
  "speakers": ["Speaker 1", "Speaker 2"],
  "summary": "2-3 sentence summary"
}`,
}
```

---

## Preparing Audio Files (ffmpeg)

Some models work best with mono 16kHz WAV. Convert with ffmpeg before sending:

```bash
# Convert to mono 16kHz WAV
ffmpeg -i input.mp4 -ar 16000 -ac 1 -c:a pcm_s16le output.wav

# Extract audio from video
ffmpeg -i video.mp4 -vn -acodec libmp3lame output.mp3

# Compress large audio
ffmpeg -i recording.wav -b:a 64k output.mp3
```

---

## File Size Limits

- Maximum audio payload: ~**25MB** as base64
- For longer recordings, split the audio into segments:

```js
// Pseudocode: split and transcribe in chunks
const chunkDurationSec = 300; // 5 minutes per chunk
// Use ffmpeg to split: ffmpeg -i audio.mp3 -f segment -segment_time 300 chunk_%03d.mp3
// Then loop over chunks and concatenate transcripts
```

---

## Batch Transcription

```js
async function batchTranscribe(audioPaths) {
  const results = [];
  for (const audioPath of audioPaths) {
    const ext = audioPath.split(".").pop();
    const base64 = fs.readFileSync(audioPath).toString("base64");

    const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${DUCKMIND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "openai/whisper-large-v3",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: "Transcribe this audio accurately." },
              { type: "input_audio", input_audio: { data: base64, format: ext } },
            ],
          },
        ],
      }),
    });

    const data = await res.json();
    results.push({ file: audioPath, transcript: data.choices[0].message.content });
  }
  return results;
}
```

---

## Language Support

`whisper-large-v3` supports 99 languages including:
- Vietnamese (`vi`)
- English, French, German, Spanish, Portuguese
- Chinese (Mandarin), Japanese, Korean
- Arabic, Hindi, Russian

Always mention the target language in the prompt when working with non-English audio for best results.

---

## Limitations

- **No URL support**: Audio must always be base64-encoded (unlike images which support URLs).
- **25MB cap**: Large files must be split before sending.
- **No real-time streaming input**: `input_audio` is for pre-recorded files. For real-time speech, use audio output streaming (see main SKILL.md Audio Output section).
- **Format availability**: Not all formats work on all models — prefer `wav` or `mp3` for maximum compatibility.
- **Whisper limitations**: Struggles with heavy background noise, overlapping speech, and very strong accents.
