# Image Generation — Detailed Reference

## Model Discovery

Find image generation models:
1. **Models page**: Filter by output modalities → "image"
2. **Chatroom**: Click the "Image" button to auto-filter
3. **API**: Check `output_modalities` includes `"image"`

## Compatible Models (examples)

- `google/gemini-3.1-flash-image-preview` (extended aspect ratios, 0.5K support)
- `google/gemini-2.5-flash-image-preview`
- `google/gemini-3-pro-image-preview`
- `black-forest-labs/flux.2-pro`
- `black-forest-labs/flux.2-flex`
- `sourceful/riverflow-v2-standard-preview`
- `sourceful/riverflow-v2-fast`
- `sourceful/riverflow-v2-pro`

## Modalities Parameter

- Models outputting both text and images: `modalities: ["image", "text"]`
- Image-only models (Flux, Sourceful): `modalities: ["image"]`

## Image Config Options

### Aspect Ratio (`image_config.aspect_ratio`)

Standard ratios (all models):

| Ratio | Resolution    |
|-------|--------------|
| 1:1   | 1024×1024 (default) |
| 2:3   | 832×1248     |
| 3:2   | 1248×832     |
| 3:4   | 864×1184     |
| 4:3   | 1184×864     |
| 4:5   | 896×1152     |
| 5:4   | 1152×896     |
| 9:16  | 768×1344     |
| 16:9  | 1344×768     |
| 21:9  | 1536×672     |

Extended ratios (Gemini 3.1 Flash only):

| Ratio | Use Case                              |
|-------|---------------------------------------|
| 1:4   | Scrolling carousels, vertical UI      |
| 4:1   | Hero banners, horizontal layouts      |
| 1:8   | Notification headers, narrow vertical |
| 8:1   | Wide-format banners, panoramic        |

### Image Size (`image_config.image_size`)

| Size | Description                          |
|------|--------------------------------------|
| 1K   | Standard resolution (default)        |
| 2K   | Higher resolution                    |
| 4K   | Highest resolution                   |
| 0.5K | Lower resolution, efficient (Gemini 3.1 Flash only) |

### Font Inputs (`image_config.font_inputs`) — Sourceful only

Render custom text with specific fonts. Max 2 font inputs, +$0.03 each.

```json
{
  "image_config": {
    "font_inputs": [
      { "font_url": "https://example.com/fonts/custom.ttf", "text": "Hello World" }
    ]
  }
}
```

Tips:
- Include the text in your prompt with font name, color, size, position details
- `text` should match exactly what's in the prompt (no extra wording or quotes)
- Use line breaks or double spaces to separate headlines and sub-headers
- Works best with short, clear headlines

### Super Resolution References (`image_config.super_resolution_references`) — Sourceful only

Enhance low-quality elements using high-quality reference images. Only works with image-to-image (input images in messages). Max 4 references, +$0.20 each.

```json
{
  "image_config": {
    "super_resolution_references": [
      "https://example.com/ref1.jpg",
      "https://example.com/ref2.jpg"
    ]
  }
}
```

Tips:
- Output matches input image size — use larger inputs for better quality
- Use high-quality references showing desired enhancement result

## Streaming Image Generation

Works with `stream: true`. Images arrive in `delta.images[]` within SSE chunks:

```js
// In each SSE chunk:
parsed.choices[0].delta.images?.forEach(img => {
  console.log(img.image_url.url); // base64 data URL
});
```

## Response Format

```json
{
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "Description text...",
      "images": [{
        "type": "image_url",
        "image_url": { "url": "data:image/png;base64,..." }
      }]
    }
  }]
}
```

- Format: base64-encoded data URLs, typically PNG
- Some models can generate multiple images per response
