# OCR — Detailed Reference

## How OCR Works on DuckMind

OCR (Optical Character Recognition) on DuckMind has two distinct paths:

1. **Image OCR** — send an image (`image_url`) to a vision model with an extraction prompt. The model reads the image and returns the text directly in its response.
2. **PDF OCR** — send a PDF with the `mistral-ocr` engine via `plugins`. DuckMind extracts text + images from scanned or image-based PDFs and passes the result to the model.

Both paths use the same `/api/v1/chat/completions` endpoint.

---

## Model Selection

| Model | Use case | Notes |
|-------|----------|-------|
| `qwen/qwen2.5-vl-32b-instruct` | Best overall image OCR | ~75% accuracy on benchmarks, strong multilingual |
| `qwen/qwen2.5-vl-72b-instruct` | Maximum accuracy | Slower, higher cost |
| `google/gemini-3.1-flash-lite-preview` | Fast, cheap | Good for clean documents |
| `google/gemini-3.1-pro-preview` | Complex layouts, tables | Best for mixed text/image layouts |
| `mistral-ocr` engine (PDF plugin) | Scanned PDFs | $2/1000 pages, handles scan artifacts well |

For **Vietnamese or other non-Latin scripts**, prefer Qwen models — they lead multilingual OCR benchmarks.

---

## Image OCR

### Via URL
```js
const result = await fetch("https://openrouter.ai/api/v1/chat/completions", {
  method: "POST",
  headers: {
    Authorization: `Bearer ${DUCKMIND_API_KEY}`,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    model: "qwen/qwen2.5-vl-32b-instruct",
    messages: [
      {
        role: "user",
        content: [
          {
            type: "text",
            text: "Extract all text from this image. Preserve layout and formatting. Return as markdown.",
          },
          {
            type: "image_url",
            image_url: { url: "https://example.com/document.jpg" },
          },
        ],
      },
    ],
  }),
});

const data = await result.json();
console.log(data.choices[0].message.content);
```

### Via Base64 (local file)
```js
import * as fs from "fs";

function toBase64Image(filePath, mimeType = "image/jpeg") {
  const buffer = fs.readFileSync(filePath);
  return `data:${mimeType};base64,${buffer.toString("base64")}`;
}

const imageUrl = toBase64Image("./scan.png", "image/png");

const result = await fetch("https://openrouter.ai/api/v1/chat/completions", {
  method: "POST",
  headers: {
    Authorization: `Bearer ${DUCKMIND_API_KEY}`,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    model: "qwen/qwen2.5-vl-32b-instruct",
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: "Extract all text from this image line by line." },
          { type: "image_url", image_url: { url: imageUrl } },
        ],
      },
    ],
  }),
});
```

### Multiple images in one request
```js
content: [
  { type: "text", text: "Extract text from each image and label them Page 1, Page 2, etc." },
  { type: "image_url", image_url: { url: base64Page1 } },
  { type: "image_url", image_url: { url: base64Page2 } },
  { type: "image_url", image_url: { url: base64Page3 } },
]
```

---

## SDK Usage (TypeScript)

```ts
import { OpenRouter } from "@openrouter/sdk";

const client = new OpenRouter({ apiKey: process.env.DUCKMIND_API_KEY });

const response = await client.chat.send({
  model: "qwen/qwen2.5-vl-32b-instruct",
  messages: [
    {
      role: "user",
      content: [
        { type: "text", text: "OCR this image, preserve all text and layout." },
        { type: "imageUrl", imageUrl: { url: base64Image } }, // camelCase in SDK
      ],
    },
  ],
});

console.log(response.choices[0].message.content);
```

Note: the SDK uses **camelCase** (`imageUrl`, `inputAudio`, `fileData`). Raw fetch uses **snake_case** (`image_url`, `input_audio`, `file_data`).

---

## PDF OCR

For scanned PDFs or PDFs that are image-based (not text-selectable), use the `mistral-ocr` engine:

```js
const pdfBase64 = `data:application/pdf;base64,${fs.readFileSync("scan.pdf").toString("base64")}`;

const result = await fetch("https://openrouter.ai/api/v1/chat/completions", {
  method: "POST",
  headers: {
    Authorization: `Bearer ${DUCKMIND_API_KEY}`,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    model: "qwen/qwen2.5-vl-32b-instruct",
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: "Extract all text from this scanned PDF." },
          {
            type: "file",
            file: { filename: "scan.pdf", file_data: pdfBase64 },
          },
        ],
      },
    ],
    plugins: [{ id: "file-parser", pdf: { engine: "mistral-ocr" } }],
  }),
});
```

Engine options:

| Engine | Cost | Best For |
|--------|------|----------|
| `pdf-text` | Free | Selectable-text PDFs |
| `mistral-ocr` | $2/1000 pages | Scanned/image PDFs |
| `native` | Input token cost | Models with built-in PDF support |

For purely text-based PDFs (text already selectable), use `pdf-text` (free) — see `pdf-processing.md`.

---

## OCR Prompts

Prompt quality significantly affects OCR accuracy. Use specific instructions:

| Goal | Prompt |
|------|--------|
| Plain extraction | `"Extract all text from the image exactly as it appears."` |
| Preserve layout | `"Extract all text, preserving line breaks, columns, and formatting. Output as markdown."` |
| Tables | `"Extract the table from this image. Output as a markdown table."` |
| Multilingual | `"Extract all text including Vietnamese/Chinese/Japanese characters. Do not translate."` |
| Handwriting | `"Transcribe the handwritten text in this image. If uncertain about a word, mark it with [?]."` |
| Structured data | `"Extract the form fields and their values as JSON key-value pairs."` |
| Mixed content | `"Extract text only, ignoring logos, decorative elements, and images."` |

---

## Structured Output from OCR

To get OCR results as structured JSON, add output format instructions to the prompt:

```js
{
  type: "text",
  text: `Extract the invoice data from this image and return ONLY valid JSON with this structure:
{
  "invoice_number": "...",
  "date": "...",
  "vendor": "...",
  "line_items": [{ "description": "...", "qty": 0, "unit_price": 0, "total": 0 }],
  "total": 0
}`,
}
```

---

## Batch OCR (Multiple Images)

For processing many images, loop sequentially or use `Promise.all` with rate limit caution:

```js
async function batchOCR(imagePaths) {
  const results = [];
  for (const imgPath of imagePaths) {
    const base64 = toBase64Image(imgPath);
    const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${DUCKMIND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "qwen/qwen2.5-vl-32b-instruct",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: "Extract all text from the image." },
              { type: "image_url", image_url: { url: base64 } },
            ],
          },
        ],
      }),
    });
    const data = await res.json();
    results.push({ file: imgPath, text: data.choices[0].message.content });
  }
  return results;
}
```

---

## Language Support

Qwen2.5-VL and Qwen3-VL models support OCR in:
- Latin scripts: English, French, German, Spanish, Portuguese, etc.
- CJK: Chinese (Simplified & Traditional), Japanese, Korean
- Southeast Asian: Vietnamese, Thai, Indonesian
- Arabic, Hebrew, Cyrillic

Always specify the expected language in the prompt when possible: `"Extract Vietnamese text from this image."` helps the model avoid transliterating or translating.

---

## Limitations

- **Image size**: DuckMind resizes images larger than 2000×2000 before upload. For high-resolution documents, prefer PDF input.
- **Handwriting**: Accuracy varies widely. Use models like Qwen2.5-VL-72B for better handwriting recognition.
- **Rate limits**: Free-tier Qwen models have lower rate limits — use paid tiers for batch workloads.
- **Complex layouts**: Multi-column, mixed text/image documents may need post-processing. Use Gemini Pro models for layout-heavy content.
- **Audio OCR**: Not supported — audio transcription is a separate modality (see main SKILL.md Audio section).
