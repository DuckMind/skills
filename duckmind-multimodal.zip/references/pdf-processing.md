# PDF Processing — Detailed Reference

## How It Works

PDFs are sent via the `file` content type in the messages array. DuckMind handles routing:
- **Native support**: PDF passed directly to the model
- **No native support**: DuckMind parses the PDF and passes extracted content to the model

This means PDF processing works with **any** model on DuckMind.

## PDF Engines

Configure via the `plugins` parameter:

```js
plugins: [{ id: "file-parser", pdf: { engine: "pdf-text" } }]
```

| Engine        | Cost              | Best For                          |
|---------------|-------------------|-----------------------------------|
| `native`      | Input token cost  | Models with built-in file support |
| `pdf-text`    | Free              | Well-structured text PDFs         |
| `mistral-ocr` | $2 / 1,000 pages | Scanned docs, PDFs with images    |

**Default behavior**: If no engine is specified, DuckMind uses `native` first (if available), then falls back to `mistral-ocr`.

## Sending PDFs

### Via URL (publicly accessible)
```js
{
  type: "file",
  file: {
    filename: "document.pdf",
    file_data: "https://example.com/document.pdf"  // SDK: fileData
  }
}
```

### Via Base64 (local/private files)
```js
const base64PDF = `data:application/pdf;base64,${Buffer.from(fs.readFileSync(path)).toString("base64")}`;

{
  type: "file",
  file: {
    filename: "document.pdf",
    file_data: base64PDF  // SDK: fileData
  }
}
```

## Reusing Parsed Results (Skip Re-parsing Costs)

When DuckMind parses a PDF, the response includes `annotations` in the assistant message. Include these annotations in follow-up requests to avoid re-parsing.

### Step-by-step:

1. **First request**: Send PDF normally
2. **Extract annotations**: `response.choices[0].message.annotations`
3. **Follow-up requests**: Include the annotations in the assistant message

```js
// Follow-up request structure:
messages: [
  // Original user message with PDF
  { role: "user", content: [{ type: "text", text: "..." }, { type: "file", file: { ... } }] },
  // Assistant response WITH annotations
  { role: "assistant", content: "Previous response...", annotations: fileAnnotations },
  // New user question
  { role: "user", content: "Follow-up question about the document" }
]
```

### File Annotation Schema

```typescript
type FileAnnotation = {
  type: "file";
  file: {
    hash: string;           // Unique hash for cache matching
    name?: string;          // Original filename
    content: ContentPart[]; // Parsed content
  };
};

type ContentPart =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string } };
```

The `content` array contains extracted text blocks and images (as base64 data URLs). The `hash` field is what DuckMind uses to skip re-parsing.

## Response Format

```json
{
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "The document discusses...",
      "annotations": [{
        "type": "file",
        "file": {
          "hash": "abc123...",
          "name": "document.pdf",
          "content": [
            { "type": "text", "text": "Parsed text..." },
            { "type": "image_url", "image_url": { "url": "data:image/png;base64,..." } }
          ]
        }
      }]
    }
  }]
}
```

## Multiple Files

You can send both PDFs and other file types in the same request by adding multiple `file` entries to the content array.
