# Video Analysis — Detailed Reference

## How It Works

Videos are sent via the `video_url` content type in the messages array. The model receives both the visual frames and the audio track — no separate transcription step is needed.

- Gemini models sample approximately **1 frame per second** by default, which suits most standard video content.
- Audio is also analysed, so transcription, tone, and speaker detection all work in a single call.
- Models with 1M-token context windows (e.g. `google/gemini-3.1-pro-preview`) can handle longer recordings.

## Compatible Models

Use the [Models page](https://openrouter.ai/models) and filter by **video** in the input modalities. Examples:

| Model | Context | Notes |
|---|---|---|
| `google/gemini-3.1-pro-preview` | 1M tokens | Full video + audio, YouTube URLs supported |
| `google/gemini-3.1-flash-preview` | 1M tokens | Faster, lower cost |
| `google/gemini-2.5-pro-preview` | 1M tokens | Higher reasoning |

> Provider-specific URL support (e.g. YouTube links) only applies to Gemini models accessed via AI Studio routing. For maximum compatibility, prefer base64 or a direct public MP4 URL.

## Sending Videos

### Via Public URL

```js
content: [
  { type: "text", text: "Summarise the key moments of this video." },
  {
    type: "video_url",
    video_url: { url: "https://example.com/recording.mp4" }
  }
]
```

### Via YouTube URL (Gemini only)

```js
content: [
  { type: "text", text: "What are the main topics discussed?" },
  {
    type: "video_url",
    video_url: { url: "https://www.youtube.com/watch?v=XXXX" }
  }
]
```

### Via Base64 (local / private files)

```js
const base64Video = `data:video/mp4;base64,${Buffer.from(fs.readFileSync("video.mp4")).toString("base64")}`;

content: [
  { type: "text", text: "Describe this video in detail." },
  {
    type: "video_url",
    video_url: { url: base64Video }
  }
]
```

Supported MIME types: `video/mp4`, `video/webm`, `video/mov`, `video/avi` (model-dependent).

## Full Request Example

```js
const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
  method: "POST",
  headers: {
    Authorization: `Bearer ${DUCKMIND_API_KEY}`,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    model: "google/gemini-3.1-pro-preview",
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: "Summarise this video with timestamps for each key moment." },
          { type: "video_url", video_url: { url: "https://example.com/recording.mp4" } },
        ],
      },
    ],
    stream: false,
  }),
});

const data = await response.json();
console.log(data.choices[0].message.content);
```

## SDK Usage

Using the `@openrouter/sdk` TypeScript SDK (camelCase parameters):

```ts
import { OpenRouter } from "@openrouter/sdk";
import * as fs from "fs";

const client = new OpenRouter({ apiKey: process.env.DUCKMIND_API_KEY });

const base64Video = `data:video/mp4;base64,${fs.readFileSync("video.mp4").toString("base64")}`;

const result = await client.chat.send({
  model: "google/gemini-3.1-pro-preview",
  messages: [
    {
      role: "user",
      content: [
        { type: "text", text: "Describe the video and list the main topics." },
        { type: "videoUrl", videoUrl: { url: base64Video } },
      ],
    },
  ],
  stream: false,
});

console.log(result.choices[0].message.content);
```

> Note: SDK uses camelCase (`videoUrl`). Raw fetch uses snake_case (`video_url`).

## Prompt Strategies

| Goal | Example Prompt |
|---|---|
| General summary | `"Summarise this video in 3–5 sentences."` |
| Timestamped breakdown | `"Describe key events in the video with timestamps."` |
| Transcript extraction | `"Transcribe all spoken dialogue from this video."` |
| Sentiment / behaviour | `"Analyse the speaker's tone and emotional delivery."` |
| Insight extraction | `"List the 5 most important takeaways from this presentation."` |
| Scene description | `"Describe each scene change and what is happening visually."` |

## Multi-turn Video Analysis

Once a video has been sent, subsequent turns can ask follow-up questions. Include the full conversation history in each request — the model has no memory between calls.

```js
messages: [
  {
    role: "user",
    content: [
      { type: "text", text: "What is this video about?" },
      { type: "video_url", video_url: { url: videoUrl } },
    ],
  },
  {
    role: "assistant",
    content: "The video covers...",
  },
  {
    role: "user",
    content: "Can you give me a timestamped breakdown?",
  },
]
```

## Response Format

Standard chat completions response — no special fields:

```json
{
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "The video begins with..."
    }
  }]
}
```

## Limitations

- **No URL caching**: Unlike PDFs (which support annotation reuse), there is no built-in mechanism to cache parsed video frames across requests. Each call re-processes the video.
- **File size**: Large base64-encoded videos significantly increase request payload. For videos over ~20 MB, prefer a public URL.
- **Frame rate**: Models sample ~1 frame/second. Rapid visual changes (e.g. fast-cut editing) may be under-sampled.
- **URL support**: YouTube and other hosted URLs only work with provider-native routing (Gemini). For other models, use base64 or a direct file URL.
