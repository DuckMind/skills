---
name: duckmind-transcribe
description: Transcribe audio files using OpenRouter API with audio-capable models (Gemini, GPT-4o-audio, etc). Use this skill whenever the user asks to transcribe audio, convert speech to text, get a transcript from an audio file, or work with audio recordings (.m4a, .mp3, .wav, .ogg, .flac, .aac, .wma, .opus). Also trigger when the user mentions voice memos, meeting recordings, podcast transcriptions, interview audio, or any task involving extracting text from audio content. Requires OPENROUTER_API_KEY environment variable and ffmpeg installed on the system.
---
# OpenRouter Audio Transcription
Transcribe audio files via OpenRouter chat completions API using the input_audio content type. Compatible with any audio-capable model on OpenRouter (Gemini, GPT-4o-audio, etc).
## Prerequisites
Before running the transcription script, verify these dependencies are available:
```bash
for cmd in curl ffmpeg base64 jq; do
  command -v "$cmd" >/dev/null 2>&1 || echo "Missing: $cmd"
done
```
The OPENROUTER_API_KEY environment variable must be set. If not available, retrieve it from DeepQuark's auth store (see **API Key** section below).
## API Key
Before making any API call, retrieve the DuckMind API key from DeepQuark's auth store:
```bash
# With jq (preferred)
DUCKMIND_API_KEY=$(jq -r '.duckmind.key' ~/.local/share/deepquark/auth.json)
# With python3 (fallback)
DUCKMIND_API_KEY=$(python3 -c "import json; d=json.load(open('$HOME/.local/share/deepquark/auth.json')); print(d['duckmind']['key'])")
```
Use `$DUCKMIND_API_KEY` (bash) or the extracted string as the Bearer token in all requests. Never hardcode the key.
## Quick Start
The main script is at {baseDir}/scripts/transcribe.sh. Make it executable first:
```bash
chmod +x {baseDir}/scripts/transcribe.sh
```
Basic transcription:
```bash
{baseDir}/scripts/transcribe.sh /path/to/audio.m4a
```
Output goes to stdout by default.
## Options
| Flag | Description | Default |
|------|-------------|---------|
| --model <model> | OpenRouter model ID | google/gemini-2.5-flash |
| --prompt <text> | Custom transcription instructions | Standard transcription prompt |
| --out <file> | Save transcript to file | stdout |
| --title <name> | Caller ID for OpenRouter dashboard | Duckmina |
| --referer <url> | HTTP-Referer header | https://duckmind.ai |
## Usage Examples
```bash
# Transcribe with a different model
{baseDir}/scripts/transcribe.sh audio.ogg --model openai/gpt-4o-audio-preview
# Custom instructions (speaker labels, timestamps)
{baseDir}/scripts/transcribe.sh meeting.m4a --prompt "Transcribe with speaker labels and timestamps"
# Save output to a file
{baseDir}/scripts/transcribe.sh interview.m4a --out /tmp/transcript.txt
# Combine options
{baseDir}/scripts/transcribe.sh podcast.mp3 --model openai/gpt-4o-audio-preview --prompt "Include timestamps" --out transcript.md
```
## How It Works
1. Audio conversion: ffmpeg converts the input to WAV (mono, 16kHz) for consistent API compatibility
2. Base64 encoding: The WAV file is base64-encoded
3. API request: Sends the audio as input_audio content to OpenRouter chat completions endpoint
4. Extraction: Pulls the transcript text from the API response
## Workflow
When a user asks to transcribe audio:
1. Check that the audio file exists (look in /mnt/user-data/uploads/ for uploaded files)
2. Retrieve `DUCKMIND_API_KEY` from `~/.local/share/deepquark/auth.json` (see **API Key** section). If the file is missing or the key is empty, ask the user
3. Verify ffmpeg is installed. If not, try `apt-get install -y ffmpeg`
4. Run the transcription script with appropriate options
5. If the user wants the transcript saved, use --out or redirect stdout to a file
6. Present the transcript to the user, and optionally save to /mnt/user-data/outputs/
## Troubleshooting
- ffmpeg format errors: The script uses a temp directory (not mktemp -t file.wav) because macOS mktemp adds random suffixes after the extension, breaking format detection
- Argument list too long: Large audio files produce huge base64 strings. The script handles this by writing to temp files instead of passing data as CLI arguments
- Empty response: Usually caused by an invalid API key, unsupported model, or corrupted audio. The script dumps the raw response for debugging
- Model does not support audio: Switch to a known audio-capable model like google/gemini-2.5-flash or openai/gpt-4o-audio-preview