# Slicer Backends

Use real slicer CLIs for mesh-to-G-code work. Do not rely on Bambu Studio as the default backend for this skill.

## Backend Order

1. `orcaslicer`
2. `prusa-slicer`
3. `curaengine`

If no preferred backend is installed, report the missing dependency.
Do not install a slicer without the user's explicit approval. After an approved
installation, rerun `scripts/gcode_tool.py discover`. Treat executables found
through `PATH`, backend-specific environment variables, or application bundle
locations as local code execution and confirm the selected absolute executable
path before slicing.

`scripts/gcode_tool.py discover` checks PATH and backend-specific environment variables:

- `ORCASLICER_BIN`
- `PRUSASLICER_BIN`
- `CURAENGINE_BIN`

Bambu Studio may also be reported as available but not preferred. It is intentionally excluded from default backend selection because the local Bambu CLI export path has previously crashed during `.gcode.3mf` generation.

## Profile Expectations

Every slice needs a wrapper profile JSON. The wrapper must include:

- `backend`: one of `orcaslicer`, `prusa-slicer`, or `curaengine`.
- `native_config`: absolute path to the primary native slicer config/profile file.
- `machine.bed_size_mm`: `[width, depth]` in millimeters.
- `machine.z_height_mm`: maximum Z travel in millimeters.
- `machine.motion_bounds_mm`: optional per-axis motion limits for native start/end G-code that intentionally moves outside the printable area.
- `filament.type`, `filament.nozzle_temp_c`, and `filament.bed_temp_c`.

The wrapper is not a complete slicer profile. The native config is authoritative for detailed printer, process, and filament settings.

For OrcaSlicer profiles split across native machine, process, and filament JSON files, add:

- `native_settings`: string or list of absolute paths passed to `--load-settings`.
- `native_filaments`: string or list of absolute paths passed to `--load-filaments`.

If `native_settings` is omitted, `native_config` is passed as the only setting file.

## Command Shapes

For OrcaSlicer:

```bash
OrcaSlicer --load-settings machine.json\;process.json --load-filaments filament.json --outputdir /tmp/out --slice 0 input.stl
```

For PrusaSlicer:

```bash
prusa-slicer --load profile.ini --export-gcode --output output.gcode input.stl
```

For CuraEngine:

```bash
CuraEngine slice -j profile.json -l input.stl -o output.gcode
```

Always run a dry-run first and inspect the emitted command before `--execute`.

## Input Handling

- `.stl`, `.obj`, and unsliced `.3mf` are passed directly to the selected slicer.
- `.ply`, `.glb`, and `.gltf` are converted to temporary STL with `trimesh` during `--execute`.
- Sliced Bambu 3MF files containing `Metadata/plate_N.gcode` are already print jobs; do not re-slice them.
- `.step`, `.stp`, `.dxf`, `.svg`, `.urdf`, and `.sdf` are out of scope for this skill. Convert them to a supported mesh first.

## Source Links

- FullControl procedural G-code context: https://github.com/FullControlXYZ/fullcontrol
- bambox Bambu packaging reference only: https://pypi.org/project/bambox/
- trimesh mesh format support: https://trimesh.org/formats.html
- CuraEngine slicing background: https://github.com/Ultimaker/CuraEngine/wiki/Slicing
