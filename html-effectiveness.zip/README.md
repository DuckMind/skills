# HTML Effectiveness Skill

> **Markdown is a wall of text. HTML is a spatial, interactive document.**

When an AI agent needs to present complex information—comparisons, timelines, decision matrices, data tables, code reviews, or system diagrams—it should create a self-contained HTML document that readers can scan, filter, explore, and interact with in the browser instead of scrolling through a long markdown answer.

Inspired by [The Unreasonable Effectiveness of HTML](https://thariqs.github.io/html-effectiveness/).

## What this is

A DM-compatible skill that guides the agent to produce one-file, zero-dependency, browser-openable interactive HTML documents for complex output.

**Core idea:** information should be spatial, scannable, and interactive rather than a linear wall of text.

## When to use it

| Scenario | Output format |
| --- | --- |
| Compare two or more options and trade-offs | HTML comparison board |
| Present more than five rows of data | Sortable/filterable HTML table |
| Show a timeline or project progress | HTML timeline |
| Make a multi-criteria decision | Decision matrix |
| Explain a concept or teach a system | Knowledge explorer |
| Review code or a pull request | Code review board |
| Describe architecture or design | Architecture diagram |
| Answer a simple question or provide a tiny fix | Plain markdown |

## Nine output patterns

1. **Comparison Board** — side-by-side cards with trade-off tags and a highlighted recommendation.
2. **Annotated Timeline** — a vertical timeline with status colors and expandable details.
3. **Interactive Report** — top-level metrics, category filters, searchable cards, and inline SVG charts.
4. **Code Review Board** — file-grouped review cards with severity labels, before/after diffs, and inline notes.
5. **Decision Matrix** — options as columns, criteria as rows, scored cells, and sortable headers.
6. **Knowledge Explorer** — collapsible panels, tabbed examples, search, and anchor navigation.
7. **Kanban Board** — draggable cards across workflow columns with markdown export.
8. **Design Token Sheet** — copyable color swatches, typography scale, and spacing reference.
9. **Slide Deck** — keyboard-navigable slides with minimal JavaScript.

## Quick start in DM

This archive is bundled through DuckMind skills. Once the DM setup/build flow syncs `DuckMind/skills`, the runtime can use the skill without fetching the upstream repository.

Trigger it directly or let the model choose it for complex output:

```text
/html-effectiveness
"Compare these three technical approaches" -> Comparison Board
"List project milestones and progress" -> Annotated Timeline
"Score candidate options across several criteria" -> Decision Matrix
```

## Generated HTML requirements

- **Single file** — all CSS and JavaScript inline, no external dependencies.
- **Zero build** — open with `file://` or any HTTP server.
- **Dark mode** — use `prefers-color-scheme`.
- **Responsive** — from 375px mobile to 1440px desktop.
- **Printable** — `@media print` expands hidden details.
- **Semantic** — HTML5 landmarks plus ARIA attributes for interactions.

## Design rules

Use neutral, high-contrast UI primitives: cards, badges, filters, tabs, collapsible sections, and clear spacing. Avoid generic SaaS templates, decorative blobs, stock image placeholders, emoji as primary visual structure, and long text walls inside the HTML.

## Workflow

1. Classify the information type and choose one of the nine patterns.
2. Extract the key dimensions: options, criteria, scores, timestamps, states, or files.
3. Write a single `.html` file with inline CSS and JavaScript.
4. Open it in the browser or serve it locally for review.
5. Refine with small edits based on user feedback.

## Demo

Open `demo/index.html`, or serve it locally:

```bash
python3 -m http.server 8080 --directory demo
```

Then visit <http://localhost:8080>.

The demo includes a comparison board, timeline, decision matrix, knowledge explorer, and interactive report.

## Provenance

Translated and adapted for DuckMind from `ghoulvspol/html-effectiveness-skill@4bbbfb8`.

## License

MIT, as declared by the upstream README.
