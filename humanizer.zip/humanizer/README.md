# Humanizer for DuckMind

DuckMind-bundled skill for making AI-looking prose sound more natural and human-written. It is adapted from `blader/humanizer` and keeps the upstream 30-pattern editing guide based on Wikipedia's "Signs of AI writing".

## Usage in DuckMind

Ask DuckMind to humanize text, or explicitly invoke the skill by name:

```text
Use the humanizer skill on this text:
[paste text]
```

For voice matching, include a short sample of the target author's writing before the text to rewrite.

## Included files

- `SKILL.md` — the DuckMind-compatible skill prompt and metadata.
- `LICENSE` — upstream MIT license.

## Source

- Upstream: https://github.com/blader/humanizer
- Upstream revision: a2ace14a88a6746f64f1f53ed8272d6788828038
- Rebrand: compatibility metadata and docs mention DuckMind while preserving the upstream prompt behavior.
