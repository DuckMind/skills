# Humanizer for DuckMind

DuckMind-bundled skill for making AI-looking prose sound more natural and human-written. It keeps the original `blader/humanizer` 30-pattern editing guide based on Wikipedia's "Signs of AI writing" and now folds in the voice-preserving edit/detect workflow from `petergyang/no-ai-slop`, rebranded as `humanizer`.

## Usage in DuckMind

Ask DuckMind to humanize text, or explicitly invoke the skill by name:

```text
Use the humanizer skill on this text:
[paste text]
```

For voice matching, include a short sample of the target author's writing before the text to rewrite. For audit-only work, ask whether a draft reads as AI-sounding and Humanizer will flag named patterns without rewriting.

## Included files

- `SKILL.md` — the DuckMind-compatible skill prompt and metadata.
- `EVAL.no-slop.md` — adapted evaluation checklist from the imported no-slop workflow.
- `agents/openai.yaml` — rebranded agent metadata kept as provenance/reference.
- `LICENSE` — upstream `blader/humanizer` MIT license.
- `LICENSE.petergyang-no-ai-slop` — upstream `petergyang/no-ai-slop` MIT license.

## Sources

- Upstream: https://github.com/blader/humanizer
- Upstream revision: a2ace14a88a6746f64f1f53ed8272d6788828038
- Added workflow: https://github.com/petergyang/no-ai-slop
- Added workflow revision: 61c21c351da4dcb40946a11fead978f2078a2c65
- Rebrand: user-facing skill name and invocation are `humanizer`; upstream names are retained only as provenance/license text.
