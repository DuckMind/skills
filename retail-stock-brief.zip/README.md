# retail-stock-brief

Skill phân tích 1 mã cổ phiếu cho người dùng phổ thông.

## Mục tiêu
- Kết hợp dữ liệu giá, dữ liệu doanh nghiệp và thảo luận/catalyst 30 ngày gần đây
- Viết lại thành ngôn ngữ dễ hiểu cho người mới
- Tránh kết luận chỉ dựa vào chart hoặc chỉ dựa vào tin tức

## Đường dẫn
- `SKILL.md` - workflow chính

## Ghi chú
Skill này ưu tiên cổ phiếu Việt Nam trước, phối hợp:
- `vnstock_market_data` cho OHLCV
If vnstock ever requires an API key, read it from `~/.dm/agent/tool-accounts.json` under the `vnstock` account (or use an existing `VNSTOCK_API_KEY` environment value); never put vnstock keys in prompts, skill files, logs, or commits.
- `/last30days` cho narrative 30 ngày
- `greedy_search` để vá các khoảng trống về catalyst/news

Deliverable của skill là **plain-text stock brief**, không bao gồm export HTML/PDF.
