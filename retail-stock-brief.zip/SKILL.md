---
name: retail-stock-brief
description: >
  Phân tích 1 mã cổ phiếu cho người dùng phổ thông bằng cách phối hợp dữ liệu giá,
  kỹ thuật cơ bản, kết quả kinh doanh và thảo luận 30 ngày gần đây.
  Use this skill whenever the user asks for a simple stock brief, retail-friendly stock analysis,
  "phân tích cổ phiếu [mã]", "mã nào đáng chú ý", "cổ phiếu này có ổn không",
  "tóm tắt mã [ticker] cho người mới", "giải thích cổ phiếu [ticker] dễ hiểu",
  "cộng đồng đang nói gì về [ticker]", "nhận định cổ phiếu [ticker]",
  "mua hay chờ với [ticker]", "phân tích theo mẫu app chứng khoán", or any request
  to summarize one stock in plain language with recent catalysts, sentiment, risk, and an
  easy-to-read verdict. Default to Vietnam-listed stocks first; if the ticker is not Vietnamese,
  fall back to the available global market-data path.
---

# Retail Stock Brief

Create a plain-language stock brief for non-expert users. The skill must answer two questions clearly:
1. **Điều gì đang xảy ra với mã này?**
2. **Người mới nên làm gì tiếp theo - mua thăm dò, chờ thêm, hay tránh vội?**

**Core rule:** never rely on price alone. A complete brief has 3 legs:
- **Market-data leg** - price/OHLCV, trend, support/resistance, valuation basics
- **Business leg** - earnings, growth, balance-sheet quality, dividend/corporate actions
- **Recency leg** - what people are saying in the last 30 days, plus fresh catalysts/controversies

**Audience:** retail / beginner investors. Prefer simple wording, short explanations, and direct takeaways.

**Disclaimer:** Educational research, not financial advice.

---

## Step 1: Detection Flow

Detect market + available tooling before analysis.

**Runtime checks**

```
!`python3 -c "import yfinance, pandas; print('YFIN_OK')" 2>/dev/null || echo "YFIN_MISSING"`
```

```
!`for py in python3.14 python3.13 python3.12 python3; do command -v "$py" >/dev/null 2>&1 || continue; "$py" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,12) else 1)' || continue; echo "$py"; break; done || true`
```

```
!`[ -f "$HOME/.npm-global/lib/node_modules/@duckmind/dm/node_modules/@duckmind/dm-darwin-arm64/extensions/dm-last30days/runtime/last30days/scripts/last30days.py" ] && echo "LAST30DAYS_OK" || echo "LAST30DAYS_MISSING"`
```

### Decision tree

| Condition | Method path |
|---|---|
| Vietnam ticker (HOSE/HNX/UPCoM, e.g. ACB, FPT, VCB) | **Path A**: `vnstock_market_data` for OHLCV + `/last30days` for 30-day narrative + `greedy_search` for gaps |
| Non-Vietnam ticker and `YFIN_OK` | **Path B**: yfinance/global data path + `/last30days` if the user wants recent narrative |
| `LAST30DAYS_OK` unavailable or result quality is weak | **Path C**: use `greedy_search` for 2-4 fresh catalyst/news searches and label social signal as sparse |
| Last30days output dominated by entity misses / unrelated threads | **Path D**: discard noisy social clusters, keep only validated web/news recency, and lower confidence |

**Hard gate:** for any full stock analysis request, always attempt the **recency leg**. Do not stop at price history only.

---

## Step 2: Normalize the Request and Set Defaults

Extract or infer the following before running tools.

| Parameter | Default |
|---|---|
| Ticker | Required; infer from company name if needed |
| Market | Vietnam if ticker matches VN listing style; otherwise global |
| Lookback price window | 6 months |
| Recency window | Last 30 days |
| Audience | Retail / beginner |
| Rating scale | 1 to 5 stars |
| Recommendation style | `Mua thăm dò` / `Theo dõi` / `Chờ xác nhận` / `Không vội mua` |
| Time horizon | Medium term / tích lũy unless user clearly says short-term or long-term |
| Output format | Plain text brief |
| Technical depth | Light - only trend, support/resistance, momentum |
| Valuation depth | Light - P/E, P/B, profit peers if available |

If the user asks “giống app / giống mẫu”, keep the structure compact and card-like in text only.

---

## Step 3: Confirm Only When Needed

Do **not** force a confirmation step for every request. Use this gate:

| Situation | Action |
|---|---|
| User already made the goal clear (e.g. “phân tích ACB cho người mới”, “theo mẫu app”, “có thêm 30 ngày gần đây”) | **Do not ask first.** Run with defaults and state assumptions in the final report. |
| Ticker is ambiguous | Ask 1 short clarifying question before analysis. |
| Time horizon changes the conclusion materially (short-term vs trung hạn vs dài hạn) and the user did not specify | Ask 1 short clarifying question before analysis. |
| User wants a “phổ thông” report but level of detail is unclear | Default to beginner-friendly; do not block unless they explicitly seem to want trader-level depth. |
| Recency/social leg is very noisy or too sparse to support a clean community section | Continue the analysis, but flag low confidence in the report instead of blocking the workflow. |

### Confirm question rules

- Ask **at most one short question** before running.
- Prefer multiple-choice style wording, for example:
  - `Bạn muốn bản này thiên về: 1) dễ hiểu cho người mới, 2) lướt sóng ngắn hạn, 3) tích lũy trung hạn?`
- If the user already gave enough signal, skip the question.
- Never ask a confirmation question just to restate what the user already said.

### If you skip confirmation

Carry these assumptions into the report:
- audience = retail / beginner
- horizon = medium-term / tích lũy
- style = easy to understand, not overly technical

Then state the assumption briefly near the end, for example:
- `Bản này đang giả định người đọc là nhà đầu tư phổ thông, thiên về góc nhìn tích lũy/trung hạn.`

---

## Step 4: Pull the 3 Data Legs

### 4A. Market-data leg

**Vietnam path:** call `vnstock_market_data action=history` with symbol, source, 6-month window, interval `1D`.
Report: latest close, 1D change, recent range, volume behavior, and trend context.

**Global fallback:** if not Vietnam and `YFIN_OK`, use the global data path for price history and valuation basics.

Extract at minimum:
- Latest close and 1D % move
- 20D / 50D / 200D trend context if available
- Near support and resistance
- 1M / 3M relative performance if possible
- P/E, P/B, and peer profit comparison if available

### 4B. Business leg

Use company announcements, earnings/news search, or the relevant finance path to gather:
- Latest quarter revenue / total operating income
- Profit (PBT/PAT or net income)
- YoY growth
- NPL / leverage / balance-sheet quality when relevant
- Dividend / bonus share / rights issue / buyback
- Management plan or annual target

### 4C. Recency leg - mandatory for full analysis

For Vietnam stocks, call `/last30days "{ticker company sector context}" --emit=compact` when the user wants analysis, sentiment, catalysts, or “what people are saying”.

Then supplement with `greedy_search` for 2-4 targeted fresh queries such as:
- `{ticker} Q1 2026 kết quả kinh doanh`
- `{ticker} cổ tức kế hoạch năm nay`
- `{ticker} catalyst 30 ngày gần đây`
- `{ticker} controversy / management / product / strategy`

**Quality gate for recency output**
- If last30days returns strong relevant threads: summarize community mood and top catalysts
- If last30days is sparse but still relevant: say discussion volume is low, not “bullish by default”
- If last30days shows unrelated entity-miss noise: ignore those clusters, rely on validated fresh news instead, and explicitly mark **social signal weak / noisy**

---

## Step 5: Convert the Data into a Retail Thesis

Synthesize the 3 data legs into a simple verdict.

### Scoring heuristics

Use 1-5 stars with this bias:
- **5⭐** - strong trend + good business + clear positive catalyst + healthy discussion quality
- **4⭐** - solid fundamentals, fair setup, some catalysts, manageable risks
- **3⭐** - mixed setup; okay business but trend or recency signal is only average
- **2⭐** - weak trend, stretched risk, or negative / noisy catalyst backdrop
- **1⭐** - avoid; severe fundamental or event risk

### Recommendation mapping

| Setup | Action |
|---|---|
| Strong but not overheated | `Mua thăm dò` |
| Good company but trend weak / waiting for trigger | `Theo dõi` or `Chờ xác nhận` |
| Quality okay but social/price momentum weak | `Tích lũy chậm, không mua đuổi` |
| Negative catalyst or broken trend | `Không vội mua` |

### Plain-language rules

- Translate jargon immediately: “NPL thấp” → “nợ xấu thấp, tức chất lượng cho vay còn tốt”
- Explain why the catalyst matters: dividend, app launch, subsidiary, management guidance, etc.
- Distinguish clearly between:
  - **Business quality**
  - **Stock price behavior**
  - **Community / news heat**
- If social discussion is thin, say so. Thin buzz is not a bullish signal.
- Use `Tín hiệu khá đồng thuận` when price, business, and recency align
- Use `Tín hiệu trung tính - cần chọn điểm vào cẩn thận` when setup is mixed
- Use `Dữ liệu thảo luận còn mỏng, nên ưu tiên quan sát hơn là vội giải ngân` when recency/social signal is weak
- Never say `rất đáng mua` unless all 3 data legs clearly support it

---

## Step 6: Respond to the User

Use this default output structure.

1. **Thông tin mã cổ phiếu**
   - Ticker, current price, % move, star rating
2. **Khuyến nghị giao dịch**
   - Action, expected upside/downside, buy zone, target, stop loss, time horizon
3. **Kịch bản mua/bán**
   - Target 1 / Target 2, stop-loss levels, plain-language risk note
4. **Nhận định chuyên gia - dễ hiểu**
   - Business performance, growth, dividend/corporate action, what changed in the last 30 days
5. **Cộng đồng đang nói gì 30 ngày qua**
   - 3-5 bullet summary of discussion mood, catalysts, complaints, controversy, or low-buzz note
6. **Điểm đánh giá tổng quan**
   - Gauge / score + one-sentence verdict for beginners
7. **So sánh cùng ngành**
   - P/E, P/B, profit, and 1 short takeaway
8. **Nguồn dữ liệu**
   - State which leg used vnstock, which used recent discussion/news, and whether last30days social signal was strong or sparse
9. **Assumption note**
   - If you skipped confirmation, state the assumed audience and horizon in one short sentence

### Final style requirements

- Write for a non-expert user
- Prefer short paragraphs and bullets
- Do not exaggerate certainty
- If confidence is low because recency data is noisy/sparse, say that explicitly in the verdict
- If you skipped confirmation because the brief was clear enough, explicitly state the assumed audience/horizon in the final note
- Keep the deliverable as a plain-text stock brief only
