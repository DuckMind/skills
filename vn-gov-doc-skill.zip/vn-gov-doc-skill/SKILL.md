---
name: vn-gov-doc-skill
description: "Vietnamese administrative document generator and normalizer compliant with official standards. Use this skill whenever a user wants to draft, create, edit, format, normalize, or validate Vietnamese administrative documents (văn bản hành chính), including công văn, quyết định, nghị quyết, tờ trình, báo cáo, thông báo, chỉ thị, kế hoạch, biên bản, giấy mời, giấy giới thiệu, văn bản Đảng, NĐ30, Hướng dẫn 36, Quyết định 4114/QĐ-BTC, thể thức văn bản, kỹ thuật trình bày, chuẩn hóa văn bản, or uploaded .docx/.doc administrative files."
---

# VN Gov Doc Skill

This skill has two complementary modes:

1. **Generate a new `.docx`** for Vietnamese administrative documents.
2. **Normalize an uploaded/existing `.docx` or `.doc`** for Nghị định 30/2020/NĐ-CP form, typing, capitalization, styles, page setup, tables, and a change report.

Always choose the mode from the user's intent. If the user asks to create/draft a new document, use generation mode. If the user uploads a file or asks to “chuẩn hóa”, “format”, “định dạng lại”, “sửa thể thức”, “áp NĐ30”, “kiểm tra thể thức”, or “sửa lỗi gõ máy”, use normalization mode.

## Standards covered

- **Nghị định 30/2020/NĐ-CP** — government administrative documents.
- **Hướng dẫn 36-HD/VPTW** — Communist Party of Vietnam documents.
- **Quyết định 4114/QĐ-BTC** — Ministry of Finance supplement to NĐ 30.
- **Phụ lục I and II of NĐ 30** — technical presentation and capitalization rules for normalization mode.

## Mode A — Generate a new document

### Step 1: clarify the document

If the user has not specified enough detail, ask:

- Government or Party document?
- Document type: công văn, quyết định, báo cáo, tờ trình, thông báo, kế hoạch, nghị quyết, etc.?
- Issuing authority and recipient?
- Main content, legal basis, signatory, place/date, and attachments?

Read the relevant references before writing code:

| Need | Reference |
|---|---|
| Government/NĐ30 details | `references/nghi-dinh-30.md` |
| Party document details | `references/huong-dan-36.md` |
| docx-js templates | `references/mau-van-ban.md` |
| Technical measurements | `references/chuan-ky-thuat.md` |
| Document type detection | `references/nhan-dien-loai-van-ban.md` |

### Step 2: generate `.docx`

Use `docx-js` (`npm install docx`) and the ready-made builder functions in `scripts/create_vbhc.js`. The output should be Word-native and easy to edit manually.

### Step 3: validate and deliver

Run the public docx skill validator when available:

```bash
python /mnt/skills/public/docx/scripts/office/validate.py output.docx
```

If validation fails, fix and revalidate before presenting the file.

## Mode B — Normalize an uploaded/existing document

Use this mode for an uploaded `.docx`/`.doc` administrative document. The goal is to return:

1. A normalized file named `<original>_chuanhoa.docx`.
2. A report named `<original>_baocao.md` that explains automatic fixes, warnings, missing/wrong components, and writing suggestions.

### Normalization pipeline

Run phases in order. Do not skip or reorder phase 2 before style application.

```text
1. Prepare input: copy upload; convert .doc to .docx if needed.
2. Unpack OOXML.
3. Detect document type and 13/14pt font pair.
4. Phase 1: fix typing, whitespace, Vietnamese tone placement, typo dictionary, capitalization.
5. Phase 2: classify paragraphs/components.
6. Phase 3: normalize styles and direct formatting.
7. Phase 4: normalize page setup for every section, including landscape.
8. Phase 5: add/fix page number headers.
9. Phase 6: check/shrink table clusters that exceed content margins.
10. Phase 7: flag missing/wrong components and produce writing suggestions.
11. Pack, validate, report, and present output files.
```

The helper pipeline is in `scripts/normalize.py` and uses only Python standard library plus the public `docx` skill unpack/pack/validate helpers.

Full-run example:

```bash
python scripts/normalize.py run \
  --input input.docx \
  --output-dir outputs \
  --font-pair 14
```

If the assistant needs tighter control, run phases manually:

```bash
python /mnt/skills/public/docx/scripts/office/unpack.py input.docx unpacked/
python scripts/normalize.py phase1 --unpacked unpacked/ --report report.json
python scripts/normalize.py phase2 --unpacked unpacked/ --doc-type "Công văn" --font-pair 14 --report report.json
python scripts/normalize.py phase3 --unpacked unpacked/ --report report.json
python scripts/normalize.py phase4 --unpacked unpacked/ --report report.json
python scripts/normalize.py phase5 --unpacked unpacked/ --report report.json
python scripts/normalize.py phase6 --unpacked unpacked/ --report report.json
python scripts/normalize.py phase7 --unpacked unpacked/ --report report.json
python /mnt/skills/public/docx/scripts/office/pack.py unpacked/ output.docx --original input.docx
python /mnt/skills/public/docx/scripts/office/validate.py output.docx
python scripts/normalize.py report --report report.json --output output_baocao.md
```

### Normalization references

| File | When to read |
|---|---|
| `references/phuluc1-the-thuc.md` | Exact NĐ30 presentation/components. |
| `references/phuluc2-viet-hoa.md` | Capitalization rules. |
| `references/chuan-ky-thuat.md` | Twips, style values, page/header parameters. |
| `references/nhan-dien-loai-van-ban.md` | 29 document types and heuristics. |
| `references/loi-go-may.md` | Typing/Unicode/whitespace/Telex correction order. |
| `references/template-bao-cao.md` | Final report format. |

## Word-native formatting rules

- Use hidden-border tables for header and footer clusters.
- Remove borders at both table and cell levels; otherwise internal gridlines can still show in Word.
- Use shape lines for decorative underlines where possible, not typed underscores.
- Keep `Times New Roman`, Unicode/TCVN 6909, black text.
- Preserve user-owned legal content. Do not invent legal bases, recipients, signatories, dates, or document numbers.
- Do not silently add missing components during normalization. Flag them in the report and ask the user before adding.
- Do not automatically rewrite legal language. Provide suggestions only.
- Do not alter condensed character spacing if the original document explicitly set it.
- Apply page setup per section, not only the first section.
- If document type cannot be detected, ask the user; do not guess.

## Report contract for normalized files

Use `references/template-bao-cao.md` and include:

- Original file name and normalized file name.
- Detected document type and font pair.
- Automatic fixes by phase.
- Missing/wrong components and table warnings.
- Writing suggestions with quoted excerpt, issue, and suggested edit.
- Any validation failure or manual follow-up needed.

## Third-party provenance

The normalization workflow, references, and Python scripts are adapted from `chuan-hoa-the-thuc` at commit `1a9e7f63dcd63931f98db2c0229ba0eb912a5cf9`, licensed CC BY 4.0. See `THIRD_PARTY_NOTICES.md` and `licenses/chuan-hoa-the-thuc-CC-BY-4.0.txt`.
