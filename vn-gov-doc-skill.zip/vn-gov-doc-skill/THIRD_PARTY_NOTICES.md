# Third-party notices

## chuan-hoa-the-thuc

This skill includes adapted references and normalization scripts from:

- Project: `chuan-hoa-the-thuc`
- Source: https://github.com/tiennnict/chuan-hoa-the-thuc.git
- Upstream revision: `1a9e7f63dcd63931f98db2c0229ba0eb912a5cf9`
- License: Creative Commons Attribution 4.0 International (CC BY 4.0)
- License text: `licenses/chuan-hoa-the-thuc-CC-BY-4.0.txt`

Adaptation notes: the upstream normalization workflow was merged into
`vn-gov-doc-skill` as an additional mode for uploaded/existing Vietnamese
administrative `.docx`/`.doc` files. The existing DM skill root, generation
workflow, and government/Party document generator remain intact.
