"""Library modules for vn-gov-doc-skill normalization mode."""
