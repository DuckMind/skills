---
name: vnstock-agent
description: Reference bundle for Vietnamese stock market research and automation using the vnstock ecosystem. Use this skill when the user needs Vietnam market data, financial statements, screeners, technical analysis, news, or pipeline patterns built around vnstock/vnstock-data/vnstock-news/vnstock-pipeline/vnstock-ta. The bundle ships curated docs, examples, and agent guidance; it does not require any bundled binary.
---

# VNStock Agent

## Overview

This skill bundles reference material for the VNStock ecosystem so DuckMind can answer or implement tasks around the Vietnamese stock market with grounded local docs.

## Included references

- `{baseDir}/README.md`
- `{baseDir}/CHANGELOG.md`
- `{baseDir}/AGENTS.md`
- `{baseDir}/docs/vnstock/**`
- `{baseDir}/docs/vnstock-data/**`
- `{baseDir}/docs/vnstock_news/**`
- `{baseDir}/docs/vnstock_pipeline/**`
- `{baseDir}/docs/vnstock_ta/**`
- `{baseDir}/demo/vnstock_agent_guide_quickstart.ipynb`

## Suggested use

Use this bundle when the user asks to:

- fetch or clean Vietnam stock data,
- inspect listings, quotes, finance, fund, commodity, or macro datasets,
- build screeners or scheduled market pipelines,
- apply technical indicators or charting around VNStock,
- work with Vietnam market news and signal extraction.

## Quick start

1. Read `{baseDir}/README.md` for the high-level project scope.
2. Open the doc family that matches the task:
   - core APIs: `{baseDir}/docs/vnstock/`
   - structured datasets: `{baseDir}/docs/vnstock-data/`
   - news workflows: `{baseDir}/docs/vnstock_news/`
   - automation pipelines: `{baseDir}/docs/vnstock_pipeline/`
   - technical analysis: `{baseDir}/docs/vnstock_ta/`
3. Use `{baseDir}/demo/vnstock_agent_guide_quickstart.ipynb` as the worked example when notebook guidance helps.

## Notes

- This bundle is documentation-first. Prefer citing the included docs before improvising API usage.
- Ignore legacy macOS metadata files if they appear in an extracted copy; the managed archive is expected to contain only the curated references above.
